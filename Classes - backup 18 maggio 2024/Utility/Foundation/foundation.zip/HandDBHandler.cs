using System;
using System.Collections.Generic;
using System.Data;
using Mono.Data.Sqlite;
using UnityEngine;

public class HandDBHandler : DatabaseObject<Hand, bool, List<Hand>, bool, bool>
{
    private string connectionString;

    public HandDBHandler(string dbPath)
    {
        this.connectionString = "URI=file:" + dbPath; // Assicurati che il percorso sia corretto
    }

    public override bool Save(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is Hand))
        {
            throw new ArgumentException("Hand object is required");
        }

        Hand hand = (Hand)parameters[0];
        bool success = false;

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = @"
                INSERT INTO Hands 
                (FrameId, DeviceID, PalmPositionX, PalmPositionY, PalmPositionZ, PalmVelocityX, PalmVelocityY, PalmVelocityZ, PalmNormalX, PalmNormalY, PalmNormalZ, DirectionX, DirectionY, DirectionZ, RotationX, RotationY, RotationZ, RotationW, GrabStrength, PinchStrength, PinchDistance, IsExtended, TimeVisible) 
                VALUES 
                (@FrameId, @DeviceID, @PalmPositionX, @PalmPositionY, @PalmPositionZ, @PalmVelocityX, @PalmVelocityY, @PalmVelocityZ, @PalmNormalX, @PalmNormalY, @PalmNormalZ, @DirectionX, @DirectionY, @DirectionZ, @RotationX, @RotationY, @RotationZ, @RotationW, @GrabStrength, @PinchStrength, @PinchDistance, @IsExtended, @TimeVisible);
                SELECT last_insert_rowid();"; // Ottiene l'ID dell'Hand inserito.

                dbCmd.CommandText = sqlQuery;
                // Aggiungi qui i parametri per l'inserimento dell'Hand, simile a quanto fatto in FingerDBHandler

                long handID = (long)dbCmd.ExecuteScalar();
                success = handID > 0;

                if (success && hand.Fingers != null)
                {
                    FingerDBHandler fingerDBHandler = DatabaseManager.Instance.GetDatabaseObjectInstance<FingerDBHandler>("FingerDBHandler");
                    if (fingerDBHandler == null)
                    {
                        UnityEngine.Debug.LogError("Impossibile ottenere FingerDBHandler dal DatabaseManager");
                        return false; // o gestire diversamente
                    }

                    // Salvataggio di ogni Finger associato all'Hand
                    foreach (Finger finger in hand.Fingers)
                    {
                        finger.HandId = (int)handID; // Imposta l'HandId del Finger
                        fingerDBHandler.Save(finger);
                    }
                }
            }
        }

        return success;
    }

    private List<Finger> LoadFingersForHand(int handID)
    {
        List<Finger> fingers = new List<Finger>();

        // Utilizza il DatabaseManager per ottenere un'istanza di FingerDBHandler
        FingerDBHandler fingerDBHandler = DatabaseManager.Instance.GetDatabaseObjectInstance<FingerDBHandler>("FingerDBHandler");
        if (fingerDBHandler == null)
        {
            UnityEngine.Debug.LogError("Impossibile ottenere FingerDBHandler dal DatabaseManager");
            return fingers; // Ritorna una lista vuota per evitare null reference exceptions
        }

        // Assumi che il metodo Search di FingerDBHandler possa accettare una coppia chiave/valore dove la chiave � il nome della colonna (in questo caso "HandId") e il valore � l'ID del Hand
        // La ricerca dovrebbe restituire tutte le Finger associate a quel HandId
        fingers = fingerDBHandler.Search("HandId", handID.ToString());

        return fingers;
    }

    public override Hand Load(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is int))
        {
            throw new ArgumentException("HandID is required as an int parameter");
        }

        int handID = (int)parameters[0];
        Hand hand = null;

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "SELECT * FROM Hands WHERE Id = @HandID";
                dbCmd.Parameters.Add(new SqliteParameter("@HandID", handID));
                dbCmd.CommandText = sqlQuery;

                using (IDataReader reader = dbCmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        hand = new Hand(
                            reader.GetInt32(reader.GetOrdinal("FrameId")),
                            reader["Id"].ToString(),
                            new List<Finger>(), // Fingers will be loaded afterwards
                            new Vector3(reader.GetFloat(reader.GetOrdinal("PalmPositionX")), reader.GetFloat(reader.GetOrdinal("PalmPositionY")), reader.GetFloat(reader.GetOrdinal("PalmPositionZ"))),
                            new Vector3(reader.GetFloat(reader.GetOrdinal("PalmVelocityX")), reader.GetFloat(reader.GetOrdinal("PalmVelocityY")), reader.GetFloat(reader.GetOrdinal("PalmVelocityZ"))),
                            new Vector3(reader.GetFloat(reader.GetOrdinal("PalmNormalX")), reader.GetFloat(reader.GetOrdinal("PalmNormalY")), reader.GetFloat(reader.GetOrdinal("PalmNormalZ"))),
                            new Vector3(reader.GetFloat(reader.GetOrdinal("DirectionX")), reader.GetFloat(reader.GetOrdinal("DirectionY")), reader.GetFloat(reader.GetOrdinal("DirectionZ"))),
                            new Quaternion(reader.GetFloat(reader.GetOrdinal("RotationX")), reader.GetFloat(reader.GetOrdinal("RotationY")), reader.GetFloat(reader.GetOrdinal("RotationZ")), reader.GetFloat(reader.GetOrdinal("RotationW"))),
                            reader.GetFloat(reader.GetOrdinal("GrabStrength")),
                            reader.GetFloat(reader.GetOrdinal("PinchStrength")),
                            reader.GetFloat(reader.GetOrdinal("PinchDistance")),
                            reader.GetBoolean(reader.GetOrdinal("IsExtended")),
                            reader.GetDouble(reader.GetOrdinal("TimeVisible"))
                        );
                    }
                }
            }

            // Now load the associated Fingers for the Hand
            if (hand != null)
            {
                hand.Fingers = LoadFingersForHand(hand.Id);
            }
        }

        return hand;
    }


    public override List<Hand> Search(params object[] parameters)
    {
        if (parameters == null || parameters.Length < 2)
        {
            throw new ArgumentException("At least two parameters are required for searching: column name and search term.");
        }

        string columnName = parameters[0] as string;
        object searchTerm = parameters[1];
        List<Hand> foundHands = new List<Hand>();

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = $"SELECT * FROM Hands WHERE {columnName} = @SearchTerm";
                dbCmd.Parameters.Add(new SqliteParameter("@SearchTerm", searchTerm));
                dbCmd.CommandText = sqlQuery;

                using (IDataReader reader = dbCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Hand hand = new Hand(
                            reader.GetInt32(reader.GetOrdinal("FrameId")),
                            reader["Id"].ToString(),
                            null, // Le Fingers verranno caricate dopo
                            new Vector3(reader.GetFloat(reader.GetOrdinal("PalmPositionX")), reader.GetFloat(reader.GetOrdinal("PalmPositionY")), reader.GetFloat(reader.GetOrdinal("PalmPositionZ"))),
                            new Vector3(reader.GetFloat(reader.GetOrdinal("PalmVelocityX")), reader.GetFloat(reader.GetOrdinal("PalmVelocityY")), reader.GetFloat(reader.GetOrdinal("PalmVelocityZ"))),
                            new Vector3(reader.GetFloat(reader.GetOrdinal("PalmNormalX")), reader.GetFloat(reader.GetOrdinal("PalmNormalY")), reader.GetFloat(reader.GetOrdinal("PalmNormalZ"))),
                            new Vector3(reader.GetFloat(reader.GetOrdinal("DirectionX")), reader.GetFloat(reader.GetOrdinal("DirectionY")), reader.GetFloat(reader.GetOrdinal("DirectionZ"))),
                            new Quaternion(reader.GetFloat(reader.GetOrdinal("RotationX")), reader.GetFloat(reader.GetOrdinal("RotationY")), reader.GetFloat(reader.GetOrdinal("RotationZ")), reader.GetFloat(reader.GetOrdinal("RotationW"))),
                            reader.GetFloat(reader.GetOrdinal("GrabStrength")),
                            reader.GetFloat(reader.GetOrdinal("PinchStrength")),
                            reader.GetFloat(reader.GetOrdinal("PinchDistance")),
                            reader.GetBoolean(reader.GetOrdinal("IsExtended")),
                            reader.GetDouble(reader.GetOrdinal("TimeVisible"))
                        );
                        // Imposta l'ID manualmente dato che il costruttore utilizza la stringa Id per ObjectId
                        hand.Id = reader.GetInt32(reader.GetOrdinal("Id"));

                        // Carica le Fingers associate a questo Hand
                        hand.Fingers = LoadFingersForHand(hand.Id);

                        foundHands.Add(hand);
                    }
                }
            }
        }

        return foundHands;
    }


    public override bool Delete(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is int))
        {
            throw new ArgumentException("HandID is required as an int parameter.");
        }

        int handID = (int)parameters[0];
        bool success = false;

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            // Prima, elimina tutte le Finger associate al Hand specificato
            bool fingersDeleted = DeleteFingersForHand(handID, dbConnection);

            if (!fingersDeleted)
            {
                UnityEngine.Debug.LogError("Errore nell'eliminazione delle Finger per il Hand con ID: " + handID);
                return false; // Oppure gestire diversamente l'errore
            }

            // Poi, elimina il Hand stesso
            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "DELETE FROM Hands WHERE Id = @HandID";
                dbCmd.Parameters.Add(new SqliteParameter("@HandID", handID));

                dbCmd.CommandText = sqlQuery;
                int rowsAffected = dbCmd.ExecuteNonQuery();

                success = rowsAffected > 0;
            }
        }

        return success;
    }

    private bool DeleteFingersForHand(int handID, IDbConnection dbConnection)
    {
        // Ottiene tutte le Finger associate al Hand
        FingerDBHandler fingerDBHandler = DatabaseManager.Instance.GetDatabaseObjectInstance<FingerDBHandler>("FingerDBHandler");
        if (fingerDBHandler == null)
        {
            UnityEngine.Debug.LogError("Impossibile ottenere FingerDBHandler dal DatabaseManager");
            return false;
        }

        List<Finger> fingers = fingerDBHandler.Search("HandId", handID.ToString());
        bool allFingersDeleted = true;

        foreach (Finger finger in fingers)
        {
            bool deleted = fingerDBHandler.Delete(finger.Id.ToString());
            if (!deleted)
            {
                UnityEngine.Debug.LogError("Impossibile eliminare Finger con ID: " + finger.Id);
                allFingersDeleted = false;
                // Potresti decidere di interrompere il ciclo qui con un `break;` se vuoi evitare di continuare dopo il primo errore.
            }
        }

        return allFingersDeleted;
    }

    public override bool Edit(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is Hand))
        {
            throw new ArgumentException("Hand object is required for editing.");
        }

        Hand handToUpdate = (Hand)parameters[0];
        bool success = false;

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            // Aggiornamento dell'oggetto Hand nel database
            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = @"
                UPDATE Hands
                SET 
                    FrameId = @FrameId, DeviceID = @DeviceID, PalmPositionX = @PalmPositionX, PalmPositionY = @PalmPositionY,
                    PalmPositionZ = @PalmPositionZ, PalmVelocityX = @PalmVelocityX, PalmVelocityY = @PalmVelocityY,
                    PalmVelocityZ = @PalmVelocityZ, PalmNormalX = @PalmNormalX, PalmNormalY = @PalmNormalY,
                    PalmNormalZ = @PalmNormalZ, DirectionX = @DirectionX, DirectionY = @DirectionY, DirectionZ = @DirectionZ,
                    RotationX = @RotationX, RotationY = @RotationY, RotationZ = @RotationZ, RotationW = @RotationW,
                    GrabStrength = @GrabStrength, PinchStrength = @PinchStrength, PinchDistance = @PinchDistance,
                    IsExtended = @IsExtended, TimeVisible = @TimeVisible
                WHERE Id = @Id";

                dbCmd.CommandText = sqlQuery;
                // Aggiungi qui i parametri SqliteParameter basati sugli attributi di Hand

                int rowsAffected = dbCmd.ExecuteNonQuery();
                success = rowsAffected > 0;
            }

            
        }

        return success;
    }

}
