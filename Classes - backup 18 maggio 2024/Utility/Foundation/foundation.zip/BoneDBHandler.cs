using System;
using System.Collections.Generic;
using System.Data;
using UnityEngine;
using Mono.Data.Sqlite;
using System.Diagnostics;

public class BoneDBHandler : DatabaseObject<Bone, bool, List<Bone>, bool, bool>
{
    private string connectionString;

    public BoneDBHandler(string dbPath)
    {
        UnityEngine.Debug.Log(dbPath);
        this.connectionString = dbPath;
    }

    // Metodo per aggiungere un osso al database
    public override bool Save(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is Bone))
        {
            throw new ArgumentException("Bone object is required");
        }

        Bone bone = (Bone)parameters[0];

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = @"INSERT INTO Bones 
                    (PrevJointX, PrevJointY, PrevJointZ, NextJointX, NextJointY, NextJointZ, CenterX, CenterY, CenterZ, RotationX, RotationY, RotationZ, RotationW, Length, Width, Type, FingerID) 
                    VALUES 
                    (@PrevJointX, @PrevJointY, @PrevJointZ, @NextJointX, @NextJointY, @NextJointZ, @CenterX, @CenterY, @CenterZ, @RotationX, @RotationY, @RotationZ, @RotationW, @Length, @Width, @Type, @FingerID)";

                dbCmd.CommandText = sqlQuery;

                // Assegna i parametri
                dbCmd.Parameters.Add(new SqliteParameter("@PrevJointX", bone.PrevJoint.x));
                dbCmd.Parameters.Add(new SqliteParameter("@PrevJointY", bone.PrevJoint.y));
                dbCmd.Parameters.Add(new SqliteParameter("@PrevJointZ", bone.PrevJoint.z));
                dbCmd.Parameters.Add(new SqliteParameter("@NextJointX", bone.NextJoint.x));
                dbCmd.Parameters.Add(new SqliteParameter("@NextJointY", bone.NextJoint.y));
                dbCmd.Parameters.Add(new SqliteParameter("@NextJointZ", bone.NextJoint.z));
                dbCmd.Parameters.Add(new SqliteParameter("@CenterX", bone.Center.x));
                dbCmd.Parameters.Add(new SqliteParameter("@CenterY", bone.Center.y));
                dbCmd.Parameters.Add(new SqliteParameter("@CenterZ", bone.Center.z));
                dbCmd.Parameters.Add(new SqliteParameter("@RotationX", bone.Rotation.x));
                dbCmd.Parameters.Add(new SqliteParameter("@RotationY", bone.Rotation.y));
                dbCmd.Parameters.Add(new SqliteParameter("@RotationZ", bone.Rotation.z));
                dbCmd.Parameters.Add(new SqliteParameter("@RotationW", bone.Rotation.w));
                dbCmd.Parameters.Add(new SqliteParameter("@Length", bone.Length));
                dbCmd.Parameters.Add(new SqliteParameter("@Width", bone.Width));
                dbCmd.Parameters.Add(new SqliteParameter("@Type", bone.Type));
                dbCmd.Parameters.Add(new SqliteParameter("@FingerID", bone.FingerID));

                dbCmd.ExecuteNonQuery();
                return true;
            }
        }
    }

    public override Bone Load(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is int))
        {
            throw new ArgumentException("BoneID is required as an int parameter");
        }

        int boneID = (int)parameters[0];
        Bone bone = null;

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "SELECT * FROM Bones WHERE BoneID = @BoneID";
                dbCmd.Parameters.Add(new SqliteParameter("@BoneID", boneID));
                dbCmd.CommandText = sqlQuery;

                using (IDataReader reader = dbCmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        bone = new Bone
                        {
                            // Assumi che ci sia una propriet� BoneID, se necessario aggiungila alla classe Bone
                            BoneID = reader.GetInt32(reader.GetOrdinal("BoneID")),
                            PrevJoint = new Vector3(reader.GetFloat(reader.GetOrdinal("PrevJointX")), reader.GetFloat(reader.GetOrdinal("PrevJointY")), reader.GetFloat(reader.GetOrdinal("PrevJointZ"))),
                            NextJoint = new Vector3(reader.GetFloat(reader.GetOrdinal("NextJointX")), reader.GetFloat(reader.GetOrdinal("NextJointY")), reader.GetFloat(reader.GetOrdinal("NextJointZ"))),
                            Center = new Vector3(reader.GetFloat(reader.GetOrdinal("CenterX")), reader.GetFloat(reader.GetOrdinal("CenterY")), reader.GetFloat(reader.GetOrdinal("CenterZ"))),
                            Rotation = new Quaternion(reader.GetFloat(reader.GetOrdinal("RotationX")), reader.GetFloat(reader.GetOrdinal("RotationY")), reader.GetFloat(reader.GetOrdinal("RotationZ")), reader.GetFloat(reader.GetOrdinal("RotationW"))),
                            Length = reader.GetFloat(reader.GetOrdinal("Length")),
                            Width = reader.GetFloat(reader.GetOrdinal("Width")),
                            Type = reader.GetInt32(reader.GetOrdinal("Type")),
                            FingerID = reader.IsDBNull(reader.GetOrdinal("FingerID")) ? 0 : reader.GetInt32(reader.GetOrdinal("FingerID")) // Gestisce il caso in cui FingerID pu� essere NULL
                        };
                    }
                    else
                    {
                        throw new Exception($"Bone not found with ID: {boneID}");
                    }
                }
            }
        }

        return bone;
    }

    public override List<Bone> Search(params object[] parameters)
    {
        // Assicurati che ci sia almeno un parametro per la ricerca
        if (parameters == null || parameters.Length != 2)
        {
            throw new ArgumentException("Two parameters are required: column name and search term.");
        }

        string columnName = parameters[0] as string;
        string searchTerm = parameters[1] as string;

        // Controlla se il nome della colonna � valido, includendo anche il nuovo attributo BoneID
        if (!IsValidColumn(columnName))
        {
            throw new ArgumentException("Invalid column name.");
        }

        List<Bone> foundBones = new List<Bone>();

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                // Adatta la query per cercare anche in base al nuovo attributo BoneID
                string sqlQuery = $"SELECT * FROM Bones WHERE {columnName} LIKE @SearchTerm";
                AddParameter(dbCmd, "@SearchTerm", "%" + searchTerm + "%");

                dbCmd.CommandText = sqlQuery;

                using (IDataReader reader = dbCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Bone bone = new Bone
                        {
                            BoneID =reader.GetInt32(reader.GetOrdinal("BoneID")),
                            PrevJoint = new Vector3(reader.GetFloat(reader.GetOrdinal("PrevJointX")), reader.GetFloat(reader.GetOrdinal("PrevJointY")), reader.GetFloat(reader.GetOrdinal("PrevJointZ"))),
                            NextJoint = new Vector3(reader.GetFloat(reader.GetOrdinal("NextJointX")), reader.GetFloat(reader.GetOrdinal("NextJointY")), reader.GetFloat(reader.GetOrdinal("NextJointZ"))),
                            Center = new Vector3(reader.GetFloat(reader.GetOrdinal("CenterX")), reader.GetFloat(reader.GetOrdinal("CenterY")), reader.GetFloat(reader.GetOrdinal("CenterZ"))),
                            Rotation = new Quaternion(reader.GetFloat(reader.GetOrdinal("RotationX")), reader.GetFloat(reader.GetOrdinal("RotationY")), reader.GetFloat(reader.GetOrdinal("RotationZ")), reader.GetFloat(reader.GetOrdinal("RotationW"))),
                            Length = reader.GetFloat(reader.GetOrdinal("Length")),
                            Width = reader.GetFloat(reader.GetOrdinal("Width")),
                            Type = reader.GetInt32(reader.GetOrdinal("Type")),
                            FingerID = reader.IsDBNull(reader.GetOrdinal("FingerID")) ? 0 : reader.GetInt32(reader.GetOrdinal("FingerID"))
                        };

                        foundBones.Add(bone);
                    }
                }
            }

            dbConnection.Close();
        }

        return foundBones;
    }

    private bool IsValidColumn(string columnName)
    {
        // Assicurati che l'elenco delle colonne valide includa il nuovo attributo BoneID
        var validColumns = new HashSet<string> { "BoneID", "PrevJointX", "PrevJointY", "PrevJointZ", "NextJointX", "NextJointY", "NextJointZ", "CenterX", "CenterY", "CenterZ", "RotationX", "RotationY", "RotationZ", "RotationW", "Length", "Width", "Type", "FingerID" };
        return validColumns.Contains(columnName);
    }


    private void AddParameter(IDbCommand command, string paramName, object value)
    {
        IDbDataParameter param = command.CreateParameter();
        param.ParameterName = paramName;
        param.Value = value;
        command.Parameters.Add(param);
    }

    public override bool Delete(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is string))
        {
            throw new ArgumentException("BoneID is required as a string parameter.");
        }

        string boneID = (string)parameters[0];

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "DELETE FROM Bones WHERE BoneID = @BoneID";
                AddParameter(dbCmd, "@BoneID", boneID);

                dbCmd.CommandText = sqlQuery;
                int rowsAffected = dbCmd.ExecuteNonQuery();

                dbConnection.Close();
                return rowsAffected > 0; // Restituisce true se almeno una riga � stata interessata, indicando che il record � stato cancellato
            }
        }
    }

    

    public override bool Edit(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is Bone))
        {
            throw new ArgumentException("Bone object is required for editing.");
        }

        Bone boneToUpdate = (Bone)parameters[0];

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = @"
            UPDATE Bones
            SET 
                PrevJointX = @PrevJointX, PrevJointY = @PrevJointY, PrevJointZ = @PrevJointZ, 
                NextJointX = @NextJointX, NextJointY = @NextJointY, NextJointZ = @NextJointZ, 
                CenterX = @CenterX, CenterY = @CenterY, CenterZ = @CenterZ, 
                RotationX = @RotationX, RotationY = @RotationY, RotationZ = @RotationZ, RotationW = @RotationW, 
                Length = @Length, Width = @Width, Type = @Type, FingerID = @FingerID
            WHERE BoneID = @BoneID";

                // Aggiunta dei parametri per la query di aggiornamento
                dbCmd.Parameters.Add(new SqliteParameter("@PrevJointX", boneToUpdate.PrevJoint.x));
                dbCmd.Parameters.Add(new SqliteParameter("@PrevJointY", boneToUpdate.PrevJoint.y));
                dbCmd.Parameters.Add(new SqliteParameter("@PrevJointZ", boneToUpdate.PrevJoint.z));
                dbCmd.Parameters.Add(new SqliteParameter("@NextJointX", boneToUpdate.NextJoint.x));
                dbCmd.Parameters.Add(new SqliteParameter("@NextJointY", boneToUpdate.NextJoint.y));
                dbCmd.Parameters.Add(new SqliteParameter("@NextJointZ", boneToUpdate.NextJoint.z));
                dbCmd.Parameters.Add(new SqliteParameter("@CenterX", boneToUpdate.Center.x));
                dbCmd.Parameters.Add(new SqliteParameter("@CenterY", boneToUpdate.Center.y));
                dbCmd.Parameters.Add(new SqliteParameter("@CenterZ", boneToUpdate.Center.z));
                dbCmd.Parameters.Add(new SqliteParameter("@RotationX", boneToUpdate.Rotation.x));
                dbCmd.Parameters.Add(new SqliteParameter("@RotationY", boneToUpdate.Rotation.y));
                dbCmd.Parameters.Add(new SqliteParameter("@RotationZ", boneToUpdate.Rotation.z));
                dbCmd.Parameters.Add(new SqliteParameter("@RotationW", boneToUpdate.Rotation.w));
                dbCmd.Parameters.Add(new SqliteParameter("@Length", boneToUpdate.Length));
                dbCmd.Parameters.Add(new SqliteParameter("@Width", boneToUpdate.Width));
                dbCmd.Parameters.Add(new SqliteParameter("@Type", boneToUpdate.Type));
                dbCmd.Parameters.Add(new SqliteParameter("@FingerID", boneToUpdate.FingerID));
                dbCmd.Parameters.Add(new SqliteParameter("@BoneID", boneToUpdate.BoneID)); // Assumi che ci sia una propriet� BoneID in Bone

                dbCmd.CommandText = sqlQuery;
                int rowsAffected = dbCmd.ExecuteNonQuery();

                dbConnection.Close();
                return rowsAffected > 0;
            }
        }
    }

}
