using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class TaskView : MonoBehaviour
{
    [SerializeField] private TMP_InputField myInputField;

    public void ShowTaskForm()
    {
        // Implementazione del metodo
    }

    public void ReceiveTaskInput()
    {
        // Implementazione del metodo
        // Restituisce un'istanza di TaskData
    }
}
