//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class LoginView : MonoBehaviour
{
    [SerializeField] private TMP_InputField txtUser;
    [SerializeField] private TMP_InputField txtPassword;
    private string userName;
    private string password;
    public void ShowLoginForm() 
    {
        // Implementazione del metodo
    }

    public void ReceiveUserInput()
    {
        Person person;
        IController<Person> logincontroller = (IController<Person>)ControllerFactory.Instance.CreateController<LoginController>("login");
        userName = txtUser.text;
        password = txtPassword.text;
        person = logincontroller.ExecuteTask(userName, password);

        if (person != null)
        {
            // Logica post-login
            Debug.Log("login eseguito");
        }
        else
        {
            // Gestire il fallimento del lsogin
        }

    }


}
