using UnityEngine;
using System.Data;
using Mono.Data.Sqlite;

public class db : MonoBehaviour
{
    private string connectionString;

    void Start()
    {
        // Imposta il percorso del database
        connectionString = "URI=file:" + Application.persistentDataPath + "/MyDatabase.db";

        // Connessione al database
        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)";
                dbCmd.CommandText = sqlQuery;
                dbCmd.ExecuteScalar();

                // Inserimento dell'utente admin
                dbCmd.CommandText = "INSERT INTO users (username, password) VALUES ('admin', 'admin')";
                dbCmd.ExecuteScalar();
            }

            dbConnection.Close();
        }

        Debug.Log("Utente admin aggiunto con successo!");
    }
}
