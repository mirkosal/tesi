using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Person
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Diagnosis { get; set; }
    public DateTime DateOfBirth { get; set; }
    public string TaxCode { get; set; } // 'CodiceFiscale' come 'TaxCode'

    // Eventuali metodi aggiuntivi
}
