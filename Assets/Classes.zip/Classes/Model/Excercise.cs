using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exercise
{
    public Type Type { get; set; } // 'Tipologia' come 'Type'
    public int Duration { get; set; } // Durata in minuti

    // Eventuali metodi aggiuntivi
}
