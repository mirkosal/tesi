using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Task
{
    public Exercise Exercise { get; set; }
    public int Repetitions { get; set; }

    // Eventuali metodi aggiuntivi
}
