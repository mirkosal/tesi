using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Type
{
    public int Number { get; set; }
    public string Difficulty { get; set; }
    public string Description { get; set; }

    // Eventuali metodi aggiuntivi
}
