using Mono.Data.Sqlite;
using UnityEngine;
using System;
using System.Collections.Generic;

public class DatabaseManager : MonoBehaviour
{
    private string connectionString;
    private Dictionary<string, Func<object>> factoryDictionary;

    void Awake()
    {
        connectionString = "URI=file:" + Application.persistentDataPath + "/database/sqlite_unity.db";

        // Inizializza il dizionario con tipi generici
        factoryDictionary = new Dictionary<string, Func<object>>
        {
            // Esempio di aggiunta di un oggetto DatabaseObject specifico
            { "PersonDBHandler", () => new PersonDBHandler(connectionString) }
            // Aggiungi qui altre mappature per altre classi
        };
    }

    public T GetDatabaseObjectInstance<T>(string className) where T : class
    {
        if (factoryDictionary.TryGetValue(className, out Func<object> factory))
        {
            return factory() as T;
        }
        else
        {
            Debug.LogError("Classe non trovata: " + className);
            return null;
        }
    }
}
