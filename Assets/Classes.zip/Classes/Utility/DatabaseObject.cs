using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class DatabaseObject<TLoad, TSave, TSearch, TDelete, TEdit>
{
    public abstract TLoad Load(params object[] parameters);
    public abstract TSave Save(params object[] parameters);
    public abstract TSearch Search(params object[] parameters);
    public abstract TDelete Delete(params object[] parameters);
    public abstract TEdit Edit(params object[] parameters);
}
