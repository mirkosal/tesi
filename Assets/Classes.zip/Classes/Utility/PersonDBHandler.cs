using System.Collections;
using System.Collections.Generic;
using System;
using System.Data;
using UnityEngine;
using Mono.Data.Sqlite;


public class PersonDBHandler: DatabaseObject<Person, bool, List<Person>, bool, bool>
{
    
    private string connectionString;

    public PersonDBHandler(string DB)
    {
        connectionString = DB;
    }

    public override Person Load(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is string))
        {
            throw new ArgumentException("TaxCode is required");
        }

        string taxCode = (string)parameters[0];

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "SELECT * FROM Persons WHERE TaxCode = @TaxCode";
                AddParameter(dbCmd, "@TaxCode", taxCode);

                dbCmd.CommandText = sqlQuery;

                using (IDataReader reader = dbCmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Person person = new Person
                        {
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Diagnosis = reader["Diagnosis"].ToString(),
                            DateOfBirth = DateTime.Parse(reader["DateOfBirth"].ToString()),
                            TaxCode = reader["TaxCode"].ToString()
                        };

                        return person;
                    }
                    else
                    {
                        throw new Exception("Person not found with TaxCode: " + taxCode);
                    }
                }
            }
        }
    }

    public override bool Save(params object[] parameters)
    {
    if (parameters == null || parameters.Length == 0 || !(parameters[0] is Person))
    {
        throw new ArgumentException("Person object is required");
    }

    Person person = (Person)parameters[0];

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "INSERT INTO Persons (FirstName, LastName, Diagnosis, DateOfBirth, TaxCode) VALUES (@FirstName, @LastName, @Diagnosis, @DateOfBirth, @TaxCode)";

                AddParameter(dbCmd, "@FirstName", person.FirstName);
                AddParameter(dbCmd, "@LastName", person.LastName);
                AddParameter(dbCmd, "@Diagnosis", person.Diagnosis);
                AddParameter(dbCmd, "@DateOfBirth", person.DateOfBirth.ToString("yyyy-MM-dd"));
                AddParameter(dbCmd, "@TaxCode", person.TaxCode);

                dbCmd.CommandText = sqlQuery;
                dbCmd.ExecuteNonQuery();
            }

            dbConnection.Close();
            return true;
        }
    }

    private void AddParameter(IDbCommand command, string paramName, object value)
    {
        IDbDataParameter param = command.CreateParameter();
        param.ParameterName = paramName;
        param.Value = value;
        command.Parameters.Add(param);
    }


    public override List<Person> Search(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is string))
        {
            throw new ArgumentException("Search term is required");
        }

        string searchTerm = (string)parameters[0];
       
        List<Person> foundPeople = new List<Person>();

        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "SELECT * FROM Persons WHERE FirstName LIKE @SearchTerm OR LastName LIKE @SearchTerm";
                AddParameter(dbCmd, "@SearchTerm", "%" + searchTerm + "%");

                dbCmd.CommandText = sqlQuery;

                using (IDataReader reader = dbCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Person person = new Person
                        {
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Diagnosis = reader["Diagnosis"].ToString(),
                            DateOfBirth = DateTime.Parse(reader["DateOfBirth"].ToString()),
                            TaxCode = reader["TaxCode"].ToString()
                        };

                        foundPeople.Add(person);
                    }
                }
            }

            dbConnection.Close();
        }
        return foundPeople;
        // Utilizza o restituisci la lista foundPeople
    }


    public override bool Delete(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is string))
        {
            throw new ArgumentException("TaxCode is required");
        }

        string taxCode = (string)parameters[0];
        
        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "DELETE FROM Persons WHERE TaxCode = @TaxCode";
                AddParameter(dbCmd, "@TaxCode", taxCode);

                dbCmd.CommandText = sqlQuery;
                dbCmd.ExecuteNonQuery();
                return true;
            }
        }
    }


    public override bool Edit(params object[] parameters)
    {
        if (parameters == null || parameters.Length == 0 || !(parameters[0] is Person))
        {
            throw new ArgumentException("Person object is required");
        }

        Person personToUpdate = (Person)parameters[0];
        
        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())
            {
                string sqlQuery = "UPDATE Persons SET FirstName = @FirstName, LastName = @LastName, Diagnosis = @Diagnosis, DateOfBirth = @DateOfBirth WHERE TaxCode = @TaxCode";

                AddParameter(dbCmd, "@FirstName", personToUpdate.FirstName);
                AddParameter(dbCmd, "@LastName", personToUpdate.LastName);
                AddParameter(dbCmd, "@Diagnosis", personToUpdate.Diagnosis);
                AddParameter(dbCmd, "@DateOfBirth", personToUpdate.DateOfBirth.ToString("yyyy-MM-dd"));
                AddParameter(dbCmd, "@TaxCode", personToUpdate.TaxCode);

                dbCmd.CommandText = sqlQuery;
                dbCmd.ExecuteNonQuery();
            }

            dbConnection.Close();
            return true;
        }
    }


}
