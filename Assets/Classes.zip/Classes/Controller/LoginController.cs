using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class LoginController : IController<Person>
{
    public Person ExecuteTask(params object[] parameters)
    {
        if (parameters.Length < 2 || parameters[0] == null || parameters[1] == null)
        {
            throw new ArgumentException("Username and password are required.");
        }

        string username = parameters[0].ToString();
        string password = parameters[1].ToString();

        // Assumi che il primo parametro sia l'username e il secondo la password

        DatabaseManager databaseManager = new DatabaseManager();
        // Specifica i cinque tipi di argomento richiesti dal DatabaseObject
        DatabaseObject<Person, bool, List<Person>, bool, bool> dbPerson = databaseManager.GetDatabaseObjectInstance<DatabaseObject<Person, bool, List<Person>, bool, bool>>("PersonDBHandler");

        // Assumi che il metodo Search restituisca una lista di Person e prendi il primo elemento
        // Assicurati che il metodo Search nella tua implementazione di DatabaseObject<Person, bool, List<Person>, bool, bool> accetti questi parametri e restituisca una lista di Person
        List<Person> searchResult = dbPerson.Search(username, password);
        if (searchResult.Count > 0)
        {
            return searchResult[0];
        }
        else
        {
            // Gestisci il caso in cui non vengono trovati risultati
            return null;
        }
    }
}
