using System;
using System.Collections.Generic;
using UnityEngine;

public class ControllerFactory
{
    private static ControllerFactory _instance;
    private Dictionary<string, Func<object>> factoryDictionary;

    public static ControllerFactory Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new ControllerFactory();
            }
            return _instance;
        }
    }

    private ControllerFactory()
    {
        factoryDictionary = new Dictionary<string, Func<object>>
        {
            { "login", () => new LoginController() }
            // Qui puoi aggiungere altri controller con diversi tipi di ritorno
        };
    }

    public T CreateController<T>(string type)
    {
        if (factoryDictionary.TryGetValue(type, out Func<object> factory))
        {
            return (T)factory();
        }
        else
        {
            throw new ArgumentException("Controller type not recognized");
        }
    }
}
