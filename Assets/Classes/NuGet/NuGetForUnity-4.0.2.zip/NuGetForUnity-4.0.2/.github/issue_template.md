## Description

[Describe the issue you have. If applicable provide logs produced by enabeling verbose logging in the NuGetForUnity settings.]

-   **NuGet Package:** [What is the name and version of the NuGet package you are installing?]
-   **NuGetForUnity Version:** [What version of NuGetForUnity are you running?]
-   **Unity Version:** [What version of Unity are you using?]
-   **Operating System:** [What OS are you on?]
