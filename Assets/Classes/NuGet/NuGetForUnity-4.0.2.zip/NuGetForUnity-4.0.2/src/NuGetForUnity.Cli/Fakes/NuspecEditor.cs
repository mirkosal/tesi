﻿namespace NugetForUnity.Ui
{
    public static class NuspecEditor
    {
        public static void CreateNuspecFile(string directory)
        {
        }
    }
}
