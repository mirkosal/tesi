﻿#nullable enable

namespace UnityEditor
{
    internal enum ApiCompatibilityLevel
    {
        None = 0,

        NET_4_6 = 3,

        NET_Standard_2_0 = 6,
    }
}
