﻿#nullable enable

using System;

namespace UnityEngine
{
    [AttributeUsage(AttributeTargets.Field)]
    internal sealed class SerializeFieldAttribute : Attribute
    {
    }
}
