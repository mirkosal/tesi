﻿namespace UnityEditor
{
    internal static class AssetDatabase
    {
        internal static void Refresh()
        {
            // do nothing
        }
    }
}
