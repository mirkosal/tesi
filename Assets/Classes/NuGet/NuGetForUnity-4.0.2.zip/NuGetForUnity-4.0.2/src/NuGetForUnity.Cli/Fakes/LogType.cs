﻿#nullable enable

namespace UnityEngine
{
    internal enum LogType
    {
        None = 0,

        Log,
    }
}
