﻿namespace UnityEngine
{
    public sealed class Texture2D
    {
    }
}
