﻿using System;

namespace UnityEditor
{
    internal class InitializeOnLoadMethodAttribute : Attribute
    {
    }
}
