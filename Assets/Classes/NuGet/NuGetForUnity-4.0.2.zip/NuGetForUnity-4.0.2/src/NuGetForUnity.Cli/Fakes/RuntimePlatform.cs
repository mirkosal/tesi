#nullable enable
namespace UnityEngine
{
    public enum RuntimePlatform
    {
        OSXEditor = 0,

        WindowsEditor = 7,

        LinuxEditor = 16,
    }
}
