﻿#nullable enable

namespace UnityEngine
{
    internal enum StackTraceLogType
    {
        None = 0,
    }
}
