dotnet publish --configuration Release $PSScriptRoot/../src/NuGetForUnity.PluginAPI/NuGetForUnity.PluginAPI.csproj
